function analyzeText() {

    const text = document
        .getElementById("textInput")
        .value
        .trim();

    if (text === "") {
        alert("Please enter some text.");
        return;
    }

    const words = text.match(/\b[\w']+\b/g) || [];

    const sentences = text
        .split(/[.!?]+/)
        .filter(sentence => sentence.trim() !== "");

    const paragraphs = text
        .split(/\n\s*\n/)
        .filter(paragraph => paragraph.trim() !== "");

    const characters = text.length;

    let totalWordLength = 0;

    words.forEach(word => {
        totalWordLength += word.length;
    });

    const averageWordLength =
        words.length > 0
            ? (totalWordLength / words.length).toFixed(2)
            : 0;

    let longestWord = "";

    words.forEach(word => {

        if (word.length > longestWord.length) {
            longestWord = word;
        }

    });

    document.getElementById("words").innerText =
        words.length;

    document.getElementById("characters").innerText =
        characters;

    document.getElementById("sentences").innerText =
        sentences.length;

    document.getElementById("paragraphs").innerText =
        paragraphs.length;

    document.getElementById("details").innerHTML = `
        <strong>Detailed Analysis</strong>
        <br>
        Average word length:
        ${averageWordLength} characters
        <br>
        Longest word:
        ${longestWord || "None"}
    `;
}

function clearText() {

    document.getElementById("textInput").value = "";

    document.getElementById("words").innerText = "0";
    document.getElementById("characters").innerText = "0";
    document.getElementById("sentences").innerText = "0";
    document.getElementById("paragraphs").innerText = "0";

    document.getElementById("details").innerHTML = "";
}